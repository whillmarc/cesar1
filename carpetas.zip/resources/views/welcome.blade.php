@extends('layouts.app')

@section('content')
<div class="container">
  <img src="../assets/images/LogoTYPBlancoGrande-03.png" class="img-responsive">
</div>
@endsection

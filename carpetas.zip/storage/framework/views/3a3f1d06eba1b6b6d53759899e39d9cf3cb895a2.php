<?php $__env->startSection('content'); ?>

<!-- ############ PAGE START-->
<div class="padding">
  
  <div class="row">
    
          <div class="col-md-12">
            <div class="box text-center">
              <p>Participantes asociados a el Cohorte <?php echo e($nomcoh); ?> en el periodo <?php echo e($fechaicoh . " / " . $fechafcoh); ?></p>
            </div>
          </div>

     <?php $__currentLoopData = $participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($participante->cohorte == $coh): ?>

    <div class="col-md-3">
      <div class="box">
        <div class="box-header btn-primary">
          <h2><?php echo e($participante->primer_nombre); ?> <?php echo e($participante->primer_apellido); ?></h2>
          <small></small>
        </div>
        <div class="box-divider m-a-0"></div>
        <div class="box-body">
          <form role="form" action="<?php echo e(url('/perfilparticipante',['id' => $participante->id,])); ?>" method="post">
             <?php echo csrf_field(); ?>


            <div class="form-group">
              <label for="exampleInputEmail1">Cedula: <?php echo e($participante->cedula); ?></label>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Correo: <?php echo e($participante->correo); ?></label>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Telefono: <?php echo e($participante->telefono_movil1); ?></label>
            </div>
            <button type="submit" class="btn success btn-block">Ver Participante</button>
          </form>
        </div>
      </div>
    </div>
    <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
   
  </div>
</div>



<!-- ############ PAGE END-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
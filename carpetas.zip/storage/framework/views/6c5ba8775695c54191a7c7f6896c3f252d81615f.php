<?php $__env->startSection('content'); ?>

<!-- ############ PAGE START-->
<div class="padding">
  
  <div class="row">
    
          <div class="col-md-12">
            <div class="box text-center">
                
          
              <p>Participantes en espera</p>
            </div>
          </div>

     <?php $__currentLoopData = $participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($participante->estatus == "espera"): ?>

    <div class="col-md-3">
      <div class="box">
        <div class="box-header">
          <h2><?php echo e($participante->primer_nombre); ?> <?php echo e($participante->primer_apellido); ?></h2>
          <small></small>
        </div>
        <div class="box-divider m-a-0"></div>
        <div class="box-body">
          <form role="form" action="<?php echo e(url('/registroPC',['id' => $participante->id,])); ?>" method="post">
             <?php echo csrf_field(); ?>


             <input type="hidden" name="idc" value="<?php echo e($id); ?>">
             <input type="hidden" name="idp" value="<?php echo e($participante->id); ?>">
               <input type="text" name="cohorte" value="<?php echo e($coh); ?>">  

            <div class="form-group">
              <label for="exampleInputEmail1">Cedula: <?php echo e($participante->cedula); ?></label>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Correo: <?php echo e($participante->correo); ?></label>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Telefono: <?php echo e($participante->telefono_movil1); ?></label>
            </div>
            <button type="submit" class="btn btn-success btn-block">Agregar</button>
          </form>
        </div>
      </div>
    </div>
    <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
   
  </div>
  <div class="row">
    
          <div class="col-md-12">
            <div class="box text-center">
              <p>Participantes asociados a un Cohorte</p>
            </div>
          </div>

     <?php $__currentLoopData = $participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($participante->estatus == "Asignado"): ?>

    <div class="col-md-3">
      <div class="box">
        <div class="box-header">
          <h2><?php echo e($participante->primer_nombre); ?> <?php echo e($participante->primer_apellido); ?></h2>
          <small></small>
        </div>
        <div class="box-divider m-a-0"></div>
        <div class="box-body">
          <form role="form" action="<?php echo e(url('/eliminarPC',['id' => $participante->id,])); ?>" method="post">
             <?php echo csrf_field(); ?>


            <div class="form-group">
              <label for="exampleInputEmail1">Cedula: <?php echo e($participante->cedula); ?></label>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Correo: <?php echo e($participante->correo); ?></label>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Telefono: <?php echo e($participante->telefono_movil1); ?></label>
            </div>
            <button type="submit" class="btn btn-danger btn-block">Eliminar</button>
          </form>
        </div>
      </div>
    </div>
    <?php endif; ?>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
   
  </div>
</div>



<!-- ############ PAGE END-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
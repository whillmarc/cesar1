<?php $__env->startSection('content'); ?>

<!-- ############ PAGE START-->
<div class="padding">
  
  <div class="row">
    
    <div class="col-md-12">
      <div class="box">
        <div class="box-header">
          <h2>Modificar Partida</h2>
          <small></small>
        </div>
        <div class="box-divider m-a-0"></div>
        <div class="box-body">
          <form role="form" action="<?php echo e(url('/modipartida')); ?>" method="post">
             <?php echo csrf_field(); ?>

             <input type="text" name="idc" value="<?php echo e($idd->id); ?>">      
            <div class="form-group">
              <label for="exmpleInputEmail1">Nombre</label>
              <input type="text" name="nombre" class="form-control" placeholder="Ingresa el nombre de la partida" value="<?php echo e($idd->nombre); ?>">
            </div>
            <div class="form-group">
              <label for="">Monto</label>
               <input type="text" name="monto" class="form-control" placeholder="Ingrese el monto de la partida" value="<?php echo e($idd->monto); ?>">
            </div>
            <button type="submit" class="btn btn-warning btn-block">Actualizar</button>
            <a type="button" href="<?php echo e(url('/proyectos')); ?>" class="btn btn-danger btn-block">Cancelar</a>
          </form>
        </div>
      </div>
    </div>
    
  </div>
</div>



<!-- ############ PAGE END-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
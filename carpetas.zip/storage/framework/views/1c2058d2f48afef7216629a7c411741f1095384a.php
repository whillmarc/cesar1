<?php $__env->startSection('content'); ?>

<!-- ############ PAGE START-->
<div class="padding">
  <div class="box">
    <div class="box-header">
              <?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <h2>Sectores</h2>
      <small>Chocolate, Mueble, Mecánica, Belleza, Agricultura, Emprendimiento, Formación Formadores, Instalación Antenas Satelitales</small>
    </div>
    <div>
      <table class="table m-b-none" ui-jp="footable" data-filter="#filter" data-page-size="5">
        <thead>
          <tr>
               <th data-toggle="true">
                  #ID
              </th>
              <th data-toggle="true">
                  Nombre
              </th>
              <th>
                  Descripci&oacute;n
              </th>
              <th data-hide="phone,tablet">
                  Editar
              </th>
              <th data-hide="phone,tablet" data-name="Date Of Birth">
                  Suspender
              </th>
              <th data-hide="phone">
                  Estado
              </th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $sectores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class=" <?php if($sec->id%2!=0): ?>
                     footable-even
           <?php else: ?> footable-odd <?php endif; ?>">
              <td><?php echo e($sec->id); ?></td>
              <td><?php echo e($sec->nombre); ?></td>
              <td><?php echo e($sec->descripcion); ?></td>
              <td><a href="<?php echo e(url('/editsector',['id' => $sec->id,])); ?>" class="btn btn-warning"  style="color:#fff">Editar</a></td>
              <?php if($sec->estado == 'Inactivo'): ?> 
            <td><a href="<?php echo e(url('/activesector',['id' => $sec->id,])); ?>" class="btn btn-success"  style="color:#fff">Activar</a></td>
            <?php else: ?>
            <td><a href="<?php echo e(url('/suspendersector',['id' => $sec->id,])); ?>" class="btn btn-danger"  style="color:#fff">Suspender</a></td>
            <?php endif; ?>
             
              <td><label class="label <?php if($sec->estado == 'Inactivo'): ?> danger <?php else: ?> success <?php endif; ?>" title=""><?php echo e($sec->estado); ?></label></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class="hide-if-no-paging">
          <tr>
              <td colspan="5" class="text-center">
                  <ul class="pagination"></ul>
              </td>
          </tr>
        </tfoot>
      </table>
      <a class="btn btn-block btn-warning" href="<?php echo e(url('/addsector')); ?>">Agregar un Sector</a>
      
    </div>
  </div>
</div>



<!-- ############ PAGE END-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
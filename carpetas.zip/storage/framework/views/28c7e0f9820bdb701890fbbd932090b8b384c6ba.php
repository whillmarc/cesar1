<?php $__env->startSection('heads'); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- ############ PAGE START-->
<div class="padding">
  <div class="box">
      
    <div class="box-header">
      <?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <h2>Listado de Participantes</h2>
      <small>Lista de información sobre los participantes a cargar en la base de datos</small>
    </div>
    <div>        
      
        <?php echo Form::open(['url'=>'/GuardarParticipante/', 'method'=>'POST']); ?>

             <?php echo csrf_field(); ?>     
        
      <label for="exampleInputEmail1">Cohorte a registrar los participantes</label>
       <br>       
            <?php if($x>0): ?>
                  
                  
                <?php $__currentLoopData = $cohortes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cohorte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($cohorte->id == $x): ?>
        
                    <select name="cohorte" class="form-control">
                        <option> <?php echo e($cohorte->id . " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Numero del cohorte: " . $cohorte->numero  . " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Nombre del cohorte: " . $cohorte->proyecto  . " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Fecha de Inicio: " . $cohorte->fecha_inicio); ?> 
                        </option>           
                    </select>            
        
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php else: ?>
            <select name="cohorte" class="form-control">
                  
                  <?php $__empty_1 = true; $__currentLoopData = $cohortes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cohorte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php $__empty_2 = true; $__currentLoopData = $participante; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participantes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                    <?php if($participantes->cohorte == $cohorte->id): ?>
                        <?php break; ?>;
                    <?php else: ?>
                    <option> <?php echo e($cohorte->id . " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Numero del cohorte: " . $cohorte->numero  . " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Nombre del cohorte: " . $cohorte->proyecto  . " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Fecha de Inicio: " . $cohorte->fecha_inicio); ?> <?php break; ?>;</option> 
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                    <option> <?php echo e($cohorte->id . " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Numero del cohorte: " . $cohorte->numero  . " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Nombre del cohorte: " . $cohorte->proyecto  . " &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Fecha de Inicio: " . $cohorte->fecha_inicio); ?> </option> 
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <option>Debes agregar un cohorte para registrar los participantes</option>
                <?php endif; ?>
              </select>
            <?php endif; ?>
        
        <select name="t" style="visibility:hidden"><option> <?php echo e($path); ?></option></select>
        
      <table class="table m-b-none" ui-jp="footable" data-filter="#filter" data-page-size="5">
        <thead>
          <tr>
               <th data-toggle="true">
                  Nombres
              </th>
              <th data-toggle="true">
                  Apellidos
              </th>
              <th>
                  Cedula
              </th> 
             <!-- <th>
                  Sexo
              </th>
              <th data-hide="phone,tablet">
                  Fecha de Nacimiento
              </th>
              <th data-hide="phone,tablet">
                  Edo. Civil
              </th>
              <th data-hide="phone">
                  Parroquia
              </th> 
              <th data-hide="phone">
                  Nivel Instruccion
              </th>
              <th data-hide="phone">
                  Situacion Empleo                              
              </th>-->
          </tr>
        </thead>
        <tbody>

          <?php $__currentLoopData = $arrays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($valor[0]); ?></td>
                <td><?php echo e($valor[2]); ?></td>
                <td><?php echo e($valor[5]); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
        <tfoot class="hide-if-no-paging">
          <tr>
              <td colspan="5" class="text-center">
                  <ul class="pagination"></ul>
              </td>
          </tr>
        </tfoot>
      </table>

        <button class="btn btn-block btn-warning" type="submit">Agregar los Participantes</button>
            <?php echo Form::close(); ?>

       
    </div>
      
  </div>
</div>



<!-- ############ PAGE END-->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script> 
<script>
  $( function() {
    $( "#datepicker2" ).datepicker();
  } );
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
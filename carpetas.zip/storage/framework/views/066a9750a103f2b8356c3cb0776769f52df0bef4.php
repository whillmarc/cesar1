<?php $__env->startSection('heads'); ?>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">
  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- ############ PAGE START-->
<div class="padding">
  
  <div class="row">
      <?php echo $__env->make('alerts.request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="col-md-12">
      <div class="box">
        <div class="box-header">
          <h2>Modificar Profesor</h2>
          <small></small>
        </div>
        <div class="box-divider m-a-0"></div>
        <div class="box-body">
          <form role="form" action="<?php echo e(url('/modiprofesor')); ?>" method="POST" files="true" enctype="multipart/form-data">
             <?php echo csrf_field(); ?>

             <input type="hidden" name="idc" class="form-control" value="<?php echo e($idd->id); ?>">                
            <div class="form-group">
              <label for="exampleInputEmail1">Primer Nombre</label>
              <input type="text" class="form-control" name="primer_nombre" placeholder="Ingrese el primer nombre" value="<?php echo e($idd->primer_nombre); ?>">
            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Segundo Nombre</label>
              <input type="text" class="form-control" name="segundo_nombre" placeholder="Ingrese el segundo nombre" value="<?php echo e($idd->segundo_nombre); ?>">
            </div>
          
            <div class="form-group">
              <label for="exampleInputPassword1">Primer Apellido</label>
              <input type="text" name="primer_apellido" class="form-control" placeholder="Ingrese el primer apellido" value="<?php echo e($idd->primer_apellido); ?>">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Segundo Apellido</label>
              <input type="text" name="segundo_apellido" class="form-control" placeholder="Ingrese el segundo apellido" value="<?php echo e($idd->segundo_apellido); ?>">
            </div>
            
              <div class="form-group">
              <label for="exampleInputEmail1">Cedula</label>
              <input type="text" name="cedula" class="form-control" placeholder="Ingrese la cedula" value="<?php echo e($idd->cedula); ?>">
            </div>

            <div class="form-group">
              <label for="exampleInputEmail1">Telefono Local</label>
              <input class="form-control" name="telefono_local" placeholder="Ingresa el telefono local" value="<?php echo e($idd->telefono_local); ?>">
            </div>
            
            <div class="form-group">
              <label for="exampleInputEmail1">Telefono Movil</label>
              <input type="text" name="telefono_movil" class="form-control" placeholder="Ingrese el telefono movil" value="<?php echo e($idd->telefono_movil); ?>"> 
            </div>

            <div class="form-group">
              <label for="exampleInputEmail1">Telefono de Oficina</label>
              <input type="text" name="telefono_oficina" class="form-control" placeholder="Ingrese el telefono de oficina" value="<?php echo e($idd->telefono_oficina); ?>">
            </div>

            <div class="form-group">
              <label for="exampleInputEmail1">Correo</label>
              <input type="email" name="correo" class="form-control" placeholder="Ingrese el correo" value="<?php echo e($idd->correo); ?>">
            </div>

            <button type="submit" class="btn btn-warning btn-block">Actualizar</button>
            <a type="button" href="<?php echo e(url('/profesores')); ?>" class="btn btn-danger btn-block">Cancelar</a>
          </form>
        </div>
      </div>
    </div>
    
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  </script> 
<script>
  $( function() {
    $( "#datepicker2" ).datepicker();
  } );
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
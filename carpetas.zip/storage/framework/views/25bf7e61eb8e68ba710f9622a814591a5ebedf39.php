<?php $__env->startSection('content'); ?>

<!-- ############ PAGE START-->
<div class="padding">
  <div class="box">
    <div class="box-header">
      <?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <h2>Centros de Formacion</h2>
      <small>Lista de información completa sobre los Centros de Formacion</small>
    </div>
    <div>
      <table class="table m-b-none" ui-jp="footable" data-filter="#filter" data-page-size="5">
        <thead>
          <tr>
               <th data-toggle="true">
                  #ID
              </th>
              <th data-toggle="true">
                  Nombre del Centro
              </th>
               <th>Rif</th>
              <th>
                  Correo
              </th> <th>
                  Banco
              </th>
              <th data-hide="phone,tablet">
                  Editar
              </th>
              <th data-hide="phone">
                  Opciones</th>
                  <th>Estado</th>
                  <th>Ver</th>
          </tr>
        </thead>
        <tbody>
           <?php $__currentLoopData = $centros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
             <td><?php echo e($centro->id); ?></td>
             <td><?php echo e($centro->nombre); ?></td>
             <td><?php echo e($centro->rif); ?></td>
             <td><?php echo e($centro->correo); ?></td>
             <td><?php echo e($centro->banco); ?></td>
             <td><a href="<?php echo e(url('/editcentro',['id' => $centro->id,])); ?>" class="btn btn-warning"  style="color:#fff">Editar</a></td>
             <?php if($centro->estado == 'Inactivo'): ?> 
            <td><a href="<?php echo e(url('/activecentro',['id' => $centro->id,])); ?>" class="btn btn-success"  style="color:#fff">Activar</a></td>
            <?php else: ?>
            <td><a href="<?php echo e(url('/suspendercentro',['id' => $centro->id,])); ?>" class="btn btn-danger"  style="color:#fff">Suspender</a></td>
            <?php endif; ?>
             <td><label class="label <?php if($centro->estado == 'Inactivo'): ?> danger <?php else: ?> success <?php endif; ?>" title=""><?php echo e($centro->estado); ?></label></td>
              <td><a href="<?php echo e(url('/perfilcentro', ['id' => $centro->id,])); ?>"><i class="fa fa-eye" style="font-size: 20px"></i></a></td>
          </tr>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class="hide-if-no-paging">
          <tr>
              <td colspan="5" class="text-center">
                  <ul class="pagination"></ul>
              </td>
          </tr>
        </tfoot>
      </table>
      <a class="btn btn-block btn-warning" href="<?php echo e(url('/addcentro')); ?>">Agregar un Centro de Formacion</a>
    </div>
  </div>
</div>



<!-- ############ PAGE END-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
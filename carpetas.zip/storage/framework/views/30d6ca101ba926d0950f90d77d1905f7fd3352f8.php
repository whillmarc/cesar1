<?php $__env->startSection('content'); ?>

<!-- ############ PAGE START-->
<div class="padding">
  <div class="box">
    <div class="box-header">
      <?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <h2>Programas</h2>
      <small>Lista de programas de acuerdo al sector perteneciente</small>
    </div>
    <div>
      <table class="table m-b-none" ui-jp="footable" data-filter="#filter" data-page-size="5">
        <thead>
          <tr>
               <th data-toggle="true">
                  #ID
              </th>
              <th data-toggle="true">
                  Sector
              </th> <th data-toggle="true">
                  Nombre
              </th>
              <th>
                  Descripci&oacute;n
              </th>
              <th data-hide="phone,tablet">
                  Editar
              </th>
              <th data-hide="phone,tablet" data-name="Date Of Birth">
                  Suspender
              </th>
              <th data-hide="phone">
                  Estado
              </th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $programa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr class=" <?php if($pro->id%2!=0): ?>
                     footable-even
           <?php else: ?> footable-odd <?php endif; ?>">
              <td><?php echo e($pro->id); ?></td>
              <td><?php echo e($pro->id_sector); ?></td>
              <td><?php echo e($pro->nombre); ?></td>
              <td><?php echo e($pro->descripcion); ?></td>
              <td><a href="<?php echo e(url('/editprograma',['id' => $pro->id,])); ?>" class="btn btn-warning"  style="color:#fff">Editar</a></td>
              <?php if($pro->estado == 'Inactivo'): ?> 
            <td><a href="<?php echo e(url('/activeprograma',['id' => $pro->id,])); ?>" class="btn btn-success"  style="color:#fff">Activar</a></td>
            <?php else: ?>
            <td><a href="<?php echo e(url('/suspenderprograma',['id' => $pro->id,])); ?>" class="btn btn-danger"  style="color:#fff">Suspender</a></td>
            <?php endif; ?>
             
              <td><label class="label <?php if($pro->estado == 'Inactivo'): ?> danger <?php else: ?> success <?php endif; ?>" title=""><?php echo e($pro->estado); ?></label></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class="hide-if-no-paging">
          <tr>
              <td colspan="5" class="text-center">
                  <ul class="pagination"></ul>
              </td>
          </tr>
        </tfoot>
      </table>
      <a class="btn btn-block btn-warning" href="<?php echo e(url('/addprogramas')); ?>">Agregar un Programa</a>
      
    </div>
  </div>
</div>



<!-- ############ PAGE END-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
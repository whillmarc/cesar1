<?php $__env->startSection('content'); ?>
<div class="padding">
	<div class="margin">
		<h5 class="m-b-0 _300">Hola <?php echo e(Auth::user()->name); ?>, Bienvenido de Nuevo</h5>
		<small class="text-muted">Sistematizaci&oacute;n TyP</small>
	</div>
	<div class="row">
		<div class="col-sm-12 col-md-5 col-lg-4">
			<div class="row">
				<div class="col-xs-6">
			        <div class="box p-a">
			          <div class="pull-left m-r">
			          	<i class="fa fa-braille text-2x text-danger m-y-sm"></i>
			          </div>
			          <div class="clear">
			          	<div class="text-muted">Sectores Activos</div>
			            <h4 class="m-a-0 text-md _600"><a href><?php echo e($sector_activo); ?></a></h4>
			          </div>
			        </div>
			    </div>
			    <div class="col-xs-6">
			        <div class="box p-a">
			          <div class="pull-left m-r">
			          	<i class="fa fa-comments text-2x text-info m-y-sm"></i>
			          </div>
			          <div class="clear">
			          	<div class="text-muted">Beneficiarios Directos e Indirectos</div>
			            <h4 class="m-a-0 text-md _600"><a href>0</a> - <a href>0</a></h4>
			          </div>
								
			        </div>
			    </div>
			    <div class="col-xs-6">
			        <div class="box p-a">
			          <div class="pull-left m-r">
			          	<i class="fa fa-clock text-2x text-accent m-y-sm"></i>
			          </div>
			          <div class="clear">
			          	<div class="text-muted">Horas de Formaci&oacute;n</div>
			            <h4 class="m-a-0 text-md _600"><a href>0</a></h4>
			          </div>
			        </div>
			    </div>
			    <div class="col-xs-3">
			        <div class="box p-a">
			          <div class="pull-left m-r">
			          	<i class="fa fa-male text-2x text-success m-y-sm"></i>
			          </div>
			          <div class="clear">
			          	<div class="text-muted">Hombres</div>
			            <h1 class="m-a-0 text-md _600"><a href><?php echo e($p_hombre); ?></a></h1>
			          </div>
			        </div>
			    </div>
				  <div class="col-xs-3">
			        <div class="box p-a">
			          <div class="pull-left m-r">
			          	<i class="fa fa-female text-2x text-accent m-y-sm"></i>
			          </div>
			          <div class="clear">
			          	<div class="text-muted">Mujeres</div>
			            <h4 class="m-a-0 text-md _600"><a href><?php echo e($p_mujer); ?></a></h4>
			          </div>
			        </div>
			    </div>
			    <div class="col-xs-12">
			        <div class="row-col box-color text-center primary">
			          <div class="row-cell p-a">
			            Total Participantes
			            <h4 class="m-a-0 text-md _600"><a href><?php echo e($participante_total); ?></a></h4>
			          </div>
			          <div class="row-cell p-a dker">
			            Estadísticas
			            <h4 class="m-a-0 text-md _600"><a href>7250</a></h4>
			          </div>
			        </div>
			    </div>
		    </div>
	    </div>
	    <div class="col-sm-12 col-md-7 col-lg-8">
	    	<div class="row-col box dark bg">
		        <div class="col-sm-8">
	        		<div class="box-header">
			          <h3>Actividades</h3>
			          <small>Tu última actividad se publicó hace 4 horas</small>
			        </div>
			        <div class="box-body">
			            <div ui-jp="plot" ui-refresh="app.setting.color" ui-options="
			              [
			                { 
			                  data: [[1, 6.1], [2, 6.3], [3, 6.4], [4, 6.6], [5, 7.0], [6, 7.7], [7, 8.3]], 
			                  points: { show: true, radius: 0}, 
			                  splines: { show: true, tension: 0.45, lineWidth: 2, fill: 0 } 
			                },
			                { 
			                  data: [[1, 5.5], [2, 5.7], [3, 6.4], [4, 7.0], [5, 7.2], [6, 7.3], [7, 7.5]], 
			                  points: { show: true, radius: 0}, 
			                  splines: { show: true, tension: 0.45, lineWidth: 2, fill: 0 } 
			                }
			              ], 
			              {
			                colors: ['#0cc2aa','#fcc100'],
			                series: { shadowSize: 3 },
			                xaxis: { show: true, font: { color: '#ccc' }, position: 'bottom' },
			                yaxis:{ show: true, font: { color: '#ccc' }},
			                grid: { hoverable: true, clickable: true, borderWidth: 0, color: 'rgba(120,120,120,0.5)' },
			                tooltip: true,
			                tooltipOpts: { content: '%x.0 is %y.4',  defaultTheme: false, shifts: { x: 0, y: -40 } }
			              }
			            " style="height:162px" >
			            </div>
			        </div>
		        </div>
		        <div class="col-sm-4 dker">
					<div class="box-header">
						<h3>Informes</h3>
					</div>
					<div class="box-body">
						<p class="text-muted">Gráficos de Emprender 360</p>
						<a href class="btn btn-sm btn-outline rounded b-success">Campus 360</a>
					</div>
		        </div>
		    </div>
	    </div>
	</div>
	<div class="row">
	    <div class="col-md-6 col-xl-4">
	        <div class="box">
	          <div class="box-header">
	            <h3>Cobertura TyP en Venezuela</h3>
	            <small>Calculado en los Ultimos 7 dias</small>
	          </div>
	          <div class="box-tool">
		        <ul class="nav">
		          <li class="nav-item inline">
		            <a class="nav-link">
		              <i class="material-icons md-18">&#xe863;</i>
		            </a>
		          </li>
		          <li class="nav-item inline dropdown">
		            <a class="nav-link" data-toggle="dropdown">
		              <i class="material-icons md-18">&#xe5d4;</i>
		            </a>
		            <div class="dropdown-menu dropdown-menu-scale pull-right">
		              <a class="dropdown-item" href>Esta Semana</a>
		              <a class="dropdown-item" href>Este Mes</a>
		              <a class="dropdown-item" href>Esta Semana</a>
		              <div class="dropdown-divider"></div>
		              <a class="dropdown-item">Hoy</a>
		            </div>
		          </li>
		        </ul>
		      </div>
	          <div class="text-center b-t">
	            <div class="row-col">
	              <div class="row-cell p-a">
	                <div class="inline m-b">
	                  <div ui-jp="easyPieChart" class="easyPieChart" ui-refresh="app.setting.color" data-redraw='true' data-percent="55" ui-options="{
	                      lineWidth: 8,
	                      trackColor: 'rgba(0,0,0,0.05)',
	                      barColor: '#0cc2aa',
	                      scaleColor: 'transparent',
	                      size: 100,
	                      scaleLength: 0,
	                      animate:{
	                        duration: 3000,
	                        enabled:true
	                      }
	                    }">
	                    <div>
	                      <h5>75%</h5>
	                    </div>
	                  </div>
	                </div>
	                <div>
	                	Alcanzada
	                	<small class="block m-b">320</small>
	                	<a href class="btn btn-sm white rounded">Gestionar</a>
	                </div>
	              </div>
	              <div class="row-cell p-a dker">
	                <div class="inline m-b">
	                  <div ui-jp="easyPieChart" class="easyPieChart" ui-refresh="app.setting.color" data-redraw='true' data-percent="45" ui-options="{
	                      lineWidth: 8,
	                      trackColor: 'rgba(0,0,0,0.05)',
	                      barColor: '#fcc100',
	                      scaleColor: 'transparent',
	                      size: 100,
	                      scaleLength: 0,
	                      animate:{
	                        duration: 3000,
	                        enabled:true
	                      }
	                    }">
	                    <div>
	                      <h5>25%</h5>
	                    </div>
	                  </div>
	                </div>
	                <div>
	                	Restante
	                	<small class="block m-b">205</small>
	                	<a href class="btn btn-sm white rounded">Gestionar</a>
	                </div>
	              </div>
	            </div>
	          </div>
	        </div>
				
	        <div class="box light lt">
	            <div class="box-header">
	              <span class="label success pull-right"><?php echo e($usuarios_totales); ?></span>
	              <h3>Usuarios</h3>
	            </div>
	            <ul class="list no-border p-b">
	            	<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	              <li class="list-item">
	                <a herf class="list-left">
	                	<span class="w-40 avatar danger">
		                  <span>C</span>
		                  <i class="on b-white bottom"></i>
		                </span>
	                </a>
	                <div class="list-body">
	                  <div><a href><?php echo e($usuario->name); ?></a></div>
	                  <small class="text-muted text-ellipsis"><?php echo e($usuario->email); ?></small>
	                </div>
	              </li>
	              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	              
	             
	            </ul>
	        </div>
				
			<div class="box">
				<div class="box-header">
					<h3>Proyectos</h3>
					<small>Cantidad <?php echo e($proyecto_total); ?></small>
				</div>
				<div class="box-tool">
			        <ul class="nav">
			          <li class="nav-item inline dropdown">
			            <a class="nav-link text-muted p-x-xs" data-toggle="dropdown">
			              <i class="fa fa-ellipsis-v"></i>
			            </a>
			            <div class="dropdown-menu dropdown-menu-scale pull-right">
			              <a class="dropdown-item" href>Nueva Tarea</a>
			              <a class="dropdown-item" href>Hacer todo terminado</a>
			              <a class="dropdown-item

                    " href>Hacer todo sin terminar</a>
			              <div class="dropdown-divider"></div>
			              <a class="dropdown-item">Configuraciones</a>
			            </div>
			          </li>
			        </ul>
			    </div>
				<div class="box-body">
				  	<div class="streamline b-l m-l">
				        <div class="sl-item b-success">
				          <div class="sl-icon">
				            <i class="fa fa-check"></i>
				          </div>
				          <?php $__currentLoopData = $proyecto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				          <div class="sl-content">
				            <div class="sl-date text-muted">Fecha de Creación: <?php echo e($p->created_at); ?></div>
				            <div>Nombre: <?php echo e($p->nombre); ?></div>
				          </div>
				          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </div>
				        
				    
				    </div>
				</div>
			  	<div class="box-footer">
			  		<a href="<?php echo e(url('/addproyecto')); ?>" class="btn btn-sm btn-outline b-info rounded text-u-c pull-right">Agrega uno</a>
			  		<a href="<?php echo e(url('/proyectos')); ?>" class="btn btn-sm white text-u-c rounded">Más</a>
			  	</div>
		  	</div>
	    </div>
	    <div class="col-md-6 col-xl-8">
	    	<div class="box">
	          <div class="box-header">
	            <h3>TyP Venezuela</h3>
	            <small>(ver mapa)</small>
	          </div>
	          <div class="box-tool">
		      </div>
					<div class="embed-responsive embed-responsive-4by3">
							<img src="/assets/images/mapadealcancetyp.jpg" class="img-responsive">
</div>
	        </div>
	    </div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
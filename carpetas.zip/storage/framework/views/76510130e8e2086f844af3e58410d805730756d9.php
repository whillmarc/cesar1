<?php $__env->startSection('content'); ?>

<!-- ############ PAGE START-->

  <div class="item">
    <div class="item-bg">
      <img src="../assets/images/naranja2.jpg" class="blur">
    </div>
    <div class="p-a-md">
      <div class="row m-t">
        <div class="col-sm-7">
          <a href class="pull-left m-r-md">
            <span class="avatar w-96">
              <img src="/movie/<?php echo e($idd->path); ?>">
              <i class="on b-white"></i>
            </span>
          </a>
          <div class="clear m-b">
            <h3 class="m-a-0 m-b-xs"><?php echo e($idd->primer_nombre); ?> <?php echo e($idd->primer_apellido); ?></h3>
            <p class="text-muted"><i class="fas fa-envelope-square"></i><span class="m-r"><strong> correo:</strong> </span><strong><?php echo e($idd->correo); ?></strong></p>
           
          </div>
        </div>
        <div class="col-sm-5">
              <h4>
                Perfil del Participante <hr/>
                
          </h4>
          <p class="text-md profile-status"><?php echo e($idd->objetivo_p); ?></p>
             
        </div>
      </div>
    </div>
  </div>
  <div class="dker p-x">
    <div class="row">
      <div class="col-sm-6 push-sm-6">
        <div class="p-y text-center text-sm-right">
          <a href class="inline p-x text-center">
            <span class="h4 block m-a-0">3</span>
            <small class="text-xs text-muted">Participantes</small>
          </a>
          <a href class="inline p-x b-l b-r text-center">
            <span class="h4 block m-a-0">250</span>
            <small class="text-xs text-muted">Colaboradores</small>
          </a>
          <a href class="inline p-x text-center">
            <span class="h4 block m-a-0">2</span>
            <small class="text-xs text-muted">Cohortes</small>
          </a>
        </div>
      </div>
      <div class="col-sm-6 pull-sm-6">
        <div class="p-y-md clearfix nav-active-primary">
          <ul class="nav nav-pills nav-sm">
            <li class="nav-item ">
              <h4>Descripcion del Participante</h4>
            </li>
           
          </ul>
        </div>
      </div>
    </div>
  </div>
  <div class="padding" style="border: 1px solid gray;">
  
      
      <div class="container">
            <div class="row justify-content-center">
              <!--<div class="col-xs-3">
                <small class="text-muted">Fecha de Registro</small>
                <div class="_500"><?php echo e($idd->created_at); ?></div>
              </div> -->
              <div class="col-xs-3">
              <div class="card text-white text-center mb-3" style="max-width: 18rem;">
                <div class="card-header" style="background-color: #F1C40F;">Participante: <?php echo e($idd->primer_nombre); ?> <?php echo e($idd->primer_apellido); ?></div>
                <div class="card-body">
                <h5 class="card-title" style="color: black;">Fecha de Registro</h5>
                <p class="card-text" style="color: black;">La fecha de registro de este participante fué el "<?php echo e($idd->created_at); ?>".</p>
                </div>
              </div>
            </div>

             <div class="col-xs-3">
              <div class="card text-white text-center mb-3" style="max-width: 18rem;">
                <div class="card-header" style="background-color: #F1C40F;">Participante: <?php echo e($idd->primer_nombre); ?> <?php echo e($idd->primer_apellido); ?></div>
                <div class="card-body">
                <h5 class="card-title" style="color: black;">Ultima Conexion</h5>
                <p class="card-text" style="color: black;">La ultima conexion de este participante fue el "<?php echo e($idd->updated_at); ?>".</p>
                </div>
              </div>
            </div>


              <!--<div class="col-xs-3">
                <small class="text-muted">Ultima conexi&oacute;n</small>
                <div class="_500"><?php echo e($idd->updated_at); ?></div>
              </div> -->            
              

              <div class="col-xs-3">
              <div class="card text-white text-center mb-3" style="max-width: 18rem;">
                <div class="card-header" style="background-color: #F1C40F;">Participante: <?php echo e($idd->primer_nombre); ?> <?php echo e($idd->primer_apellido); ?></div>
                <div class="card-body">
                <h5 class="card-title" style="color: black;">Cedula</h5>
                <p class="card-text" style="color: black;">Este participante tiene una cedula de "<?php echo e($idd->cedula); ?>".</p>
                </div>
              </div>
            </div>

              <!--<div class="col-xs-3">
                <small class="text-muted">Cedula</small>
                <div class="_500"><?php echo e($idd->cedula); ?></div>
              </div>--> 

            <div class="col-xs-3">
              <div class="card text-white text-center mb-3" style="max-width: 18rem;">
                <div class="card-header" style="background-color: #F1C40F;">Participante: <?php echo e($idd->primer_nombre); ?> <?php echo e($idd->primer_apellido); ?></div>
                <div class="card-body">
                <h5 class="card-title" style="color: black;">Estado Civil</h5>
                <p class="card-text" style="color: black;">El estado civil registro de este participante es "<?php echo e($idd->estado_civil); ?>".</p>
                </div>
              </div>
            </div>

              <!--<div class="col-xs-3">
                <small class="text-muted">Estado Civil</small>
                <div class="_500"><?php echo e($idd->estado_civil); ?></div>
              </div>-->



            </div>
      </div>

 
    <hr>
       
      
      <div class="container">
            <div class="row justify-content-center">
              
              <!--<div class="col-xs-3">
                <small class="text-muted">Lugar de Nacimiento</small>
                <div class="_500"><?php echo e($idd->lugar_nacimiento); ?></div>
              </div>-->
              <div class="col-xs-3">
              <div class="card text-white text-center mb-3" style="max-width: 18rem;">
                <div class="card-header" style="background-color: #F1C40F;">Participante: <?php echo e($idd->primer_nombre); ?> <?php echo e($idd->primer_apellido); ?></div>
                <div class="card-body">
                <h5 class="card-title" style="color: black;">Lugar de Nacimiento</h5>
                <p class="card-text" style="color: black;">El lugar de nacimiento de este participante es "<?php echo e($idd->lugar_nacimiento); ?>".</p>
                </div>
              </div>
            </div>

              <!--<div class="col-xs-3">
                <small class="text-muted">Telefono Movil</small>
                <div class="_500"><?php echo e($idd->telefono_movil1); ?></div>
              </div>-->
              <div class="col-xs-3">
              <div class="card text-white text-center mb-3" style="max-width: 18rem;">
                <div class="card-header" style="background-color: #F1C40F;">Participante: <?php echo e($idd->primer_nombre); ?> <?php echo e($idd->primer_apellido); ?></div>
                <div class="card-body">
                <h5 class="card-title" style="color: black;">Telefono Movil</h5>
                <p class="card-text" style="color: black;">El telefono movil registrado por este participante es "<?php echo e($idd->telefono_movil); ?>".</p>
                </div>
              </div>
            </div>  

              <!--<div class="col-xs-3">
                <small class="text-muted">Nivel de Instruccion</small>
                <div class="_500"><?php echo e($idd->nivel_instruccion); ?></div>
              </div>-->
              <div class="col-xs-3">
              <div class="card text-white text-center mb-3" style="max-width: 18rem;">
                <div class="card-header" style="background-color: #F1C40F;">Participante: <?php echo e($idd->primer_nombre); ?> <?php echo e($idd->primer_apellido); ?></div>
                <div class="card-body">
                <h5 class="card-title" style="color: black;">Nivel de Instruccion</h5>
                <p class="card-text" style="color: black;">El nivel de instruccion registrado de este participante es "<?php echo e($idd->nivel_instruccion); ?>".</p>
                </div>
              </div>
            </div> 

              <!--<div class="col-xs-3">
                <small class="text-muted">Facebook</small>
                <div class="_500"><?php echo e($idd->facebook); ?></div>
              </div>-->

              <div class="col-xs-3">
              <div class="card text-white text-center mb-3" style="max-width: 18rem;">
                <div class="card-header" style="background-color: #F1C40F;">Participante: <?php echo e($idd->primer_nombre); ?> <?php echo e($idd->primer_apellido); ?></div>
                <div class="card-body">
                <h5 class="card-title" style="color: black;">Facebook</h5>
                <p class="card-text" style="color: black;">El Facebook registrado por este participante es  "<?php echo e($idd->facebook); ?>".</p>
                </div>
              </div>
            </div> 

            </div>
      </div>



    <hr>


      
      <div class="container">
            <div class="row justify-content-center">
              
              <!--<div class="col-xs-3">
                <small class="text-muted">Lugar de Nacimiento</small>
                <div class="_500"><?php echo e($idd->lugar_nacimiento); ?></div>
              </div>-->
              <div class="col-xs-3">
              <div class="card text-white text-center mb-3" style="max-width: 18rem;">
                <div class="card-header" style="background-color: #F1C40F;">Participante: <?php echo e($idd->primer_nombre); ?> <?php echo e($idd->primer_apellido); ?></div>
                <div class="card-body">
                <h5 class="card-title" style="color: black;">Fecha de Nacimiento</h5>
                <p class="card-text" style="color: black;">la fecha de nacimiento de este participante es "<?php echo e($idd->fecha_nacimiento); ?>".</p>
                </div>
              </div>
            </div>

              <!--<div class="col-xs-3">
                <small class="text-muted">Telefono Movil</small>
                <div class="_500"><?php echo e($idd->telefono_movil1); ?></div>
              </div>-->
              <div class="col-xs-3">
              <div class="card text-white text-center mb-3" style="max-width: 18rem;">
                <div class="card-header" style="background-color: #F1C40F;">Participante: <?php echo e($idd->primer_nombre); ?> <?php echo e($idd->primer_apellido); ?></div>
                <div class="card-body">
                <h5 class="card-title" style="color: black;">Telefono Local</h5>
                <p class="card-text" style="color: black;">El telefono de casa registrado por este participante es "<?php echo e($idd->telefono_local); ?>".</p>
                </div>
              </div>
            </div>  

              <!--<div class="col-xs-3">
                <small class="text-muted">Nivel de Instruccion</small>
                <div class="_500"><?php echo e($idd->nivel_instruccion); ?></div>
              </div>-->
              <div class="col-xs-3">
              <div class="card text-white text-center mb-3" style="max-width: 18rem;">
                <div class="card-header" style="background-color: #F1C40F;">Participante: <?php echo e($idd->primer_nombre); ?> <?php echo e($idd->primer_apellido); ?></div>
                <div class="card-body">
                <h5 class="card-title" style="color: black;">Experiencia Laboral</h5>
                <p class="card-text" style="color: black;">La experiencia laboral registrada de este participante es "<?php echo e($idd->experiencia_laboral); ?> año(s)".</p>
                </div>
              </div>
            </div> 

              <!--<div class="col-xs-3">
                <small class="text-muted">Facebook</small>
                <div class="_500"><?php echo e($idd->facebook); ?></div>
              </div>-->

              <div class="col-xs-3">
              <div class="card text-white text-center mb-3" style="max-width: 18rem;">
                <div class="card-header" style="background-color: #F1C40F;">Participante: <?php echo e($idd->primer_nombre); ?> <?php echo e($idd->primer_apellido); ?></div>
                <div class="card-body">
                <h5 class="card-title" style="color: black;">Nacionalidad</h5>
                <p class="card-text" style="color: black;">La nacionalidad registrada por este participante es  "<?php echo e($idd->nacionalidad); ?>".</p>
                </div>
              </div>
            </div> 

            </div>
      </div>



  </div>

<!-- ############ PAGE END-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

<!-- ############ PAGE START-->
<div class="padding">
 <?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="box">

    <a class="btn btn-block btn-warning" href="<?php echo e(url('/addcohortes')); ?>">Registrar nuevo Cohorte</a>
            
</div>
</div>

     

<?php $__empty_1 = true; $__currentLoopData = $proyectos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<?php  $sum=0;  ?>
<div class="padding">
  <div class="box">
    <div class="box-header">
      <h2>Cohorte: <?php echo e($proyecto->nombre); ?></h2>
      <small>Lista de información completa sobre los Cohortes de <?php echo e($proyecto->nombre); ?></small>
    </div>
       
    <div style="margin-bottom: 20px;">        
      <table class="table m-b-none" ui-jp="footable" data-filter="#filter" data-page-size="5">
        <thead>
          <tr>
               <th data-toggle="true">
                  #ID
              </th>
              <th data-toggle="true">
                  Nombre del proyecto
              </th>
               <th>Numero de corte</th>
              <th>
                  Inicio
              </th> <th>
                  Fin
              </th>
              <th data-hide="phone,tablet" data-name="Date Of Birth">
                  Opciones
              </th>
              <th data-hide="phone">
                  Cantidad de Participantes
              </th>            
              <th>
                  Estado
              </th>
              <th data-hide="phone,tablet" data-name="Date Of Birth">
                  Configuracion
              </th>
          </tr>
        </thead>          
        <tbody>
           
            <?php $__currentLoopData = $cohortes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cohorte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($proyecto->nombre==$cohorte->proyecto): ?> 
            <tr>
             <td><?php echo e($cohorte->id); ?></td>
             <td><?php echo e($cohorte->proyecto); ?></td>
             <td><?php echo e($cohorte->numero); ?></td>
             <td><?php echo e($cohorte->fecha_inicio); ?></td>
             <td><?php echo e($cohorte->fecha_culminacion); ?></td>
            
                <?php $__empty_2 = true; $__currentLoopData = $participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                    <?php if($participante->cohorte == $cohorte->id): ?>  
                        <td><a href="<?php echo e(url('/verParticipanteCorte',['id' => $cohorte->id,])); ?>" class="btn btn-primary"  style="color:#fff">Ver Participantes</a></td> 
                        <td>
                            <label class="btn"><?php echo e($participante->where('cohorte',$participante->cohorte)->count()); ?>

                            </label>
                        </td>
                        <?php 
                        
                           $sum += $participante->where('cohorte',$participante->cohorte)->count();
                
                         ?>
                    <?php break; ?>
                    <?php else: ?>
                        <?php if($loop->last): ?>
                            <td><a href="<?php echo e(url('/addListadoParticipante',['id' => $cohorte->id,])); ?>" class="btn btn-warning"  name="" style="color:#fff">Agregar Listado</a></td> 
                            <td>
                            <label class="btn" title="">0
                            </label>
                            </td>
                        <?php endif; ?>
                
                    <?php endif; ?> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <td><a href="<?php echo e(url('/addListadoParticipante',['id' => $cohorte->id,])); ?>" class="btn btn-warning"  style="color:#fff">Agregar Listado</a></td>
                <td>
                            <label class="btn" title="">0
                            </label>
                        </td>
                <?php endif; ?>
              
                <td><label class="label <?php if($cohorte->estado == 'Inactivo'): ?> danger <?php else: ?> success <?php endif; ?>" title=""><?php echo e($cohorte->estado); ?></label></td> 
             
             <?php if($cohorte->estado == 'Inactivo'): ?> 
            <td><a href="<?php echo e(url('/activecohorte',['id' => $cohorte->id,])); ?>" class="btn btn-success"  style="color:#fff">Activar</a></td>
            <?php else: ?>
            <td><a href="<?php echo e(url('/suspendercohorte',['id' => $cohorte->id,])); ?>" class="btn btn-danger"  style="color:#fff">Suspender</a></td>
            <?php endif; ?>
             
            
               
          </tr>
            <?php endif; ?>
           
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot class="hide-if-no-paging">
          <tr>
              <td colspan="10" class="text-center">
                  <ul class="pagination" style="font-weight: bold;">Total Participantes  = <?php  echo $sum;  ?></ul>
              </td>
          </tr>
        </tfoot>
      </table>
              
        
    </div>
      
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<div class="padding">
  <div class="box">
    <div class="box-header">
      <?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <?php echo $__env->make('alerts.errors', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <h2>Debe registrar un proyecto ante de crear una cohorte</h2>
      <small>No hay proyectos cargados en la base de datos</small>
    </div>
       
      <a class="btn btn-block btn-warning" href="<?php echo e(url('/addproyecto')); ?>">Agregar un Proyecto</a>
        
        
    </div>
      
  
</div>

<?php endif; ?>

<!-- ############ PAGE END-->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>